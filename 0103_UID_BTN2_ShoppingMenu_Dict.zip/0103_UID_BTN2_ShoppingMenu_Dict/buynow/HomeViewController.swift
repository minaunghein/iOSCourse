//
//  HomeViewController.swift
//  buynow
//
//  Created by Min Aung Hein on 29/10/16.
//  Copyright © 2016 smag. All rights reserved.
//

import UIKit
//MVC MVC MVC MVC MVC......
class HomeViewController: UIViewController {
    
    //Model
    
    
    
    //IBOutlet
    
    
    
    //IBAction
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 

}
