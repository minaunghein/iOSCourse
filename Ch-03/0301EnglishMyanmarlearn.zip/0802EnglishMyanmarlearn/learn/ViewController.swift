//
//  ViewController.swift
//  learn
//
//  Created by Min Aung Hein on 4/27/19.
//  Copyright © 2019 Min Aung Hein. All rights reserved.
//

import UIKit

struct  Word {
    var id:Int
    var en:String
    var mm:String
    var s:String
    
    
    init(id:Int , en:String, mm:String , s:String ){
        self.id = id
        self.en =  en
        self.mm = mm
        self.s = s
    }
}

class ViewController: UIViewController , UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    
    let db =  SQLiteDB.shared
    var words = [Word]()  //Data collector
    var filterWords = [Word]()
    var isFilter = false //Flag
    
    //MARK: Searchbar
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isFilter = false
        filterWords = [Word]()
        tableView.reloadData()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        isFilter = true
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText != "" {
            isFilter = true
            filterWords = words.filter({ (word) -> Bool in
                return word.en.contains(searchText)   //.hasPrefix(searchText)
            })
            
        }
        else {
            isFilter = false
            filterWords = [Word]()
        }
        tableView.reloadData()
    }
    
    //MARK: TableView
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  isFilter ?    filterWords.count  : words.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =     tableView.dequeueReusableCell(withIdentifier: "cell") as? WordTableViewCell
        let currentWord =  isFilter ? filterWords[indexPath.row] : words[indexPath.row]
        cell?.configure(currentWord)
        //Single responsiblity
        //Refactoring
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let currentWord =  isFilter ? filterWords[indexPath.row] : words[indexPath.row]
         performSegue(withIdentifier: "detailsegue", sender: currentWord )
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case "detailsegue": let destVC = segue.destination as? DetailViewController
                                            destVC?.word = sender as! Word
            
        default :break
        }
    }
    
    //MARK: View
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //        tableView.estimatedRowHeight = 120
        //        tableView.rowHeight = UITableView.automaticDimension
        loadData() //Fetch DB and collect into words
    }
    
    func  loadData() {
        db.open()
        let cmd = "SELECT * from dictionary"
        let rows = db.query(sql: cmd)
        
        for row in rows {
            let id = row["_id"] as? Int    ?? 0
            let en = row["en"] as? String ?? ""
            let mm = row["mm"] as? String ?? ""
            let s =  row["s"] as? String ?? ""
            
            let aWord = Word(id: id, en: en, mm: mm, s: s)
            words.append(aWord)
        }
        
        //Testing filtering
        // words = words.filter { (word) -> Bool in
        //  return   word.s == "n"
        // }
    }
    
}

