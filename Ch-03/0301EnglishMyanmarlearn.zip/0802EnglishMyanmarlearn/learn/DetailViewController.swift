//
//  DetailViewController.swift
//  learn
//
//  Created by Min Aung Hein on 4/28/19.
//  Copyright © 2019 Min Aung Hein. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    var word:Word! //receiver
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var kindLabel: UILabel!
    @IBOutlet weak var mmLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel?.text = word.en
        kindLabel?.text = word.s
        mmLabel?.text = word.mm
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
