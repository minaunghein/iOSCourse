//
//  mybridge.h
//  learn
//
//  Created by Min Aung Hein on 4/27/19.
//  Copyright © 2019 Min Aung Hein. All rights reserved.
//

#ifndef mybridge_h
#define mybridge_h

#import "sqlite3.h"
#import <time.h>

#endif /* mybridge_h */
