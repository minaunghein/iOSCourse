//
//  WordTableViewCell.swift
//  learn
//
//  Created by Min Aung Hein on 4/27/19.
//  Copyright © 2019 Min Aung Hein. All rights reserved.
//

import UIKit

class WordTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel:UILabel!
    @IBOutlet weak var kindLabel:UILabel!
    @IBOutlet weak var  mmLabel:UILabel!
    
    func configure(_ word:Word) {
        self.titleLabel.text = word.en
        self.kindLabel.text = word.s
        self.mmLabel.text = word.mm
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
