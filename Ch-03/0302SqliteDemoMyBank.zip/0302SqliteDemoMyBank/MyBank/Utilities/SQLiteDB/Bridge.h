//
//  Bridge.h
//  MyBank
//
//  Created by mic-student5 on 4/28/19.
//  Copyright © 2019 Trainer. All rights reserved.
//

#ifndef Bridge_h
#define Bridge_h

#import "sqlite3.h"
#import <time.h>

#endif * Bridge_h */
