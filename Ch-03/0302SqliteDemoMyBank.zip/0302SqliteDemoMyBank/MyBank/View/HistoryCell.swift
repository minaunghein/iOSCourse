//
//  HistoryCell.swift
//  MyBank
//
//  Created by Min Aung Hein on 5/12/19.
//  Copyright © 2019 Trainer. All rights reserved.
//

import UIKit

class HistoryCell: UITableViewCell {

    
    @IBOutlet weak var fromidLabel: UILabel!
    @IBOutlet weak var toidLabel: UILabel!
    @IBOutlet weak var oprLabel: UILabel!
    @IBOutlet weak var amtLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    
    func config(_ trans:Transaction){
        fromidLabel.text =  "\(trans.fromid)"
        toidLabel.text =  "\(trans.toid)"
        oprLabel.text =  "\(trans.opr)"
        amtLabel.text =  "\(trans.amount)"

        dateLabel.text =  "\(trans.date.ddmmyyString)"
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
