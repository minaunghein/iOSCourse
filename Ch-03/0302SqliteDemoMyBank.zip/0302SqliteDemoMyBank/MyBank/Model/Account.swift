//
//  Account.swift
//  MyBank
//
//  Created by mic-student5 on 4/27/19.
//  Copyright © 2019 Trainer. All rights reserved.
//

import Foundation

class Account{
    
    //Propeties
    private var _id:Int
    var id:Int{
        return _id
        
    }
    private var _userName:String
    var userName:String{
        return _userName
    }
    private var _password:String
    
    var amount:Double {
        
        let cmd = "SELECT toid,fromid,opr,amt from Transactions WHERE fromid = \(id) OR toid = \(id)"
        let dbm = SQLiteDB.shared
        dbm.open()
        dbm.query(sql: cmd)
        let rows = dbm.query(sql: cmd)
        var totalAmt = 0.0
        for row in rows{
            let amt = row["amt"]as? Double ?? 0
            let opr = row["opr"]as? String ?? ""
            let fromid = row["fromid"]as? Int ?? 0
            
            if opr == "W" || (opr == "T" && fromid == id) {
                (totalAmt -= amt)
            } else {
                (totalAmt += amt)
            }
        }
        return totalAmt//TODO: calculate amount as per user operation, transaction
    }
    
    
    init(id:Int,userName:String,password:String){
        self._id = id
        self._userName = userName
        self._password = password
        
    }
    //Method
    func save(_ amount:Double)->Bool{
        //TODO: save to account db
        //Topup amount from account to account it self
        let dateSecond = Date().timeIntervalSince1970
        let cmd = "INSERT INTO Transactions(fromid,toid,opr,amt,created) VALUES(\(id),\(id),'S',\(amount),\(dateSecond))"
        let dbm = SQLiteDB.shared
        dbm.execute(sql: cmd)
        return true
    }
    
    //func withdraw(_ amount:Double)->Bool{
    func withdraw(_ amount:Double)->Bool{
        
        let dateSecond = Date().timeIntervalSince1970
        let cmd = "INSERT INTO Transactions(fromid,toid,opr,amt,created) VALUES(\(id),\(id),'W',\(amount),\(dateSecond))"
        let dbm = SQLiteDB.shared
        dbm.execute(sql: cmd)
        return true
    }
    
    // return true
    // }
    func transfer(_ amount:Double,_ toid:Int) -> Bool {
        
        let dateSecond = Date().timeIntervalSince1970
        let cmd = "INSERT INTO Transactions(fromid,toid,opr,amt,created) VALUES(\(id),\(toid),'T',\(amount),\(dateSecond))"
        let dbm = SQLiteDB.shared
        dbm.execute(sql: cmd)
        
        return true
    }
    
    func getTransactions() -> [Transaction] {
        let dbm = SQLiteDB.shared
        let cmd = "SELECT * FROM Transactions WHERE fromid = \(self.id) OR toid = \(self.id )"
        let rows = dbm.query(sql: cmd)
        var transactions = [Transaction]() //1
        
        for row in rows {
            
            let id = row["id"] as? Int
            let fromid =  row["fromid"] as? Int
            let toid =  row["toid"] as? Int
            let opr = row["opr"] as? String
            let amount = row[AMOUNTKEY] as? Double
            let datesecond = row["created"] as? Double
            
            if let id = id , let fromid = fromid , let toid = toid , let opr = opr , let amount = amount    {
                let date = Date.init(timeIntervalSince1970: datesecond ?? 0)
                let transac = Transaction(id: id, fromid: fromid, toid: toid , opr: opr, amount: amount, date: date )
                transactions.append(transac) //2
            }
            
        }
        return transactions
    }
    
}
