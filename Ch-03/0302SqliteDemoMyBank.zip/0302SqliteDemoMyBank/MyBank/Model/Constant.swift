//
//  Constant.swift
//  MyBank
//
//  Created by Min Aung Hein on 5/11/19.
//  Copyright © 2019 Trainer. All rights reserved.
//

import Foundation

let AMOUNTKEY = "amt"
