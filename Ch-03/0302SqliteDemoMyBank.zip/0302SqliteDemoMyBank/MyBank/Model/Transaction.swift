//
//  Transaction.swift
//  MyBank
//
//  Created by Min Aung Hein on 5/11/19.
//  Copyright © 2019 Trainer. All rights reserved.
//

import Foundation

class Transaction {
    
    var id:Int
    var fromid:Int
    var toid:Int
    var opr:String
    var amount :Double
    var date:Date
    
    init ( id:Int, fromid:Int, toid:Int, opr:String,amount:Double,date:Date ){
        self.id = id
        self.fromid = fromid
        self.toid =  toid
        self.opr = opr
        self.amount = amount
        self.date = date 
        
    }
    
}
