//
//  Bank.swift
//  MyBank
//
//  Created by mic-student5 on 4/27/19.
//  Copyright © 2019 Trainer. All rights reserved.
//

import Foundation



class Bank{
    
    let dbm = SQLiteDB.shared
    static var current:Bank?
    static var currentAccount:Account?//Singleton
    
    
    private var _id:Int
    var id:Int{
        return _id
    }
    
    private var _name:String
    var name:String{
        return _name
        
    }
    
    init(id:Int,name:String){
        self._id = id
        self._name = name
    }
    
    func login(username:String,password:String)->Account? {
        
        dbm.open()
        let cmd = "SELECT* FROM Accounts WHERE username = '\(username)' AND password = '\(password)'"
        
        let rows = dbm.query(sql:cmd)
        if let firstRow = rows.first {
            let id = firstRow ["id"] as? Int ?? 0
            let username = firstRow["username"]as? String ?? "" //default as "" when not found
            let password = firstRow["password"]as? String ?? ""         //TODO: find in db with provided username n password
            //If found, then create username n password
            //else return nil
            
            let account = Account(id: id, userName: username, password: password)
            return account
            
        }
        return nil
        
    }
}
