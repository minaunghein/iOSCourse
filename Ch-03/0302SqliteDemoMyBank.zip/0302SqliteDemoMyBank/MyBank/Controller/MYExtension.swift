//
//  MYExtension.swift
//  MyBank
//
//  Created by Zara on 5/5/19.
//  Copyright © 2019 Trainer. All rights reserved.
//

import Foundation
import UIKit

extension Date {
    var ddmmyyString:String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yy"
        return dateFormatter.string(from: self )
    }
}

extension UIView {

    
}


extension UITextField {
    func clear(){
        self.text = ""
    }
}

extension UIViewController {
    func alert(title:String, message:String){
        let alertCtrl = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action1 = UIAlertAction(title: "OK", style: .default) { (action) in
            print("user press ok")
        }
        //        let action2 = UIAlertAction(title: "Delete", style: .destructive) { (action) in
        //            print("Deleting")
        //        }
        
        alertCtrl.addAction(action1)
        // alertCtrl.addAction(action2)
        present(alertCtrl, animated: true, completion: nil)
        
    }
}
