//
//  LoadingViewController.swift
//  MyBank
//
//  Created by Trainer on 3/23/19.
//  Copyright © 2019 Trainer. All rights reserved.
//

import UIKit

class LoadingViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { (t) in
            self.forward()
        }
    }
    //https://dribbble.com/shots/3829985-VNPAY-App-Interactions
    func forward(){
        var runtime = UserDefaults.standard.integer(forKey:"runtime")
        if runtime >  0 {
            performSegue(withIdentifier: "loginsegue", sender: nil)
        } else {
            performSegue(withIdentifier: "onboardingsegue", sender: nil)
        }
        runtime += 1
        
        //preference
        UserDefaults.standard.set(runtime, forKey: "runtime")
        UserDefaults.standard.synchronize() //*** Save to disk from memory
        
        print(FileManager.default.urls(for: .documentDirectory, in: .userDomainMask ))
        //TODO: save time for future count
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
