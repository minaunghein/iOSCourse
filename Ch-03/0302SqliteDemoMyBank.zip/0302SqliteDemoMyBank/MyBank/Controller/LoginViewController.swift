//
//  LoginViewController.swift
//  MyBank
//
//  Created by Trainer on 3/23/19.
//  Copyright © 2019 Trainer. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    
    @IBOutlet weak var usernameTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBAction func login(_ sender: UIButton) {
        
        let dbm = SQLiteDB.shared
        
        guard let username = usernameTextField.text,username != "" else{print("Invalid username or password")
            alert(title: "Error", message: "Invalid username or password")
            
            return
            
        }
        
        guard let password = passwordTextField.text,password != "" else{print("Invalid username or password")
            alert(title: "Error", message: "Invalid username or password")
            return
        }
        //THEN here two variable username n passowrd are usable
        
        if let account = Bank.current?.login(username: username, password: password){
            print("OK,successfully login")
            Bank.currentAccount = account //For future use
            usernameTextField.clear()
            passwordTextField.clear()
            proceedToHome()
        }else{
            alert(title: "Error", message: "Invalid username or password")
            print("invalid username or password")
        }
        
        
    }
    func proceedToHome(){
        performSegue(withIdentifier: "homesegue", sender: nil)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let currentBank = Bank(id:1, name:"MYBANK")
        Bank.current = currentBank
        // Do any additional setup after loading the view.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   
}


