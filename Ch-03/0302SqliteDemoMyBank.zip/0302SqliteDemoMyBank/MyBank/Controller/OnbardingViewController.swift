//
//  OnbardingViewController.swift
//  MyBank
//
//  Created by Trainer on 3/23/19.
//  Copyright © 2019 Trainer. All rights reserved.
//

import UIKit

class OnbardingViewController: UIViewController {
    
    
    @IBOutlet weak var getStartBtn: UIButton!
    
    @IBOutlet weak var logoImageView: UIImageView!
    
    @IBOutlet weak var textView: UITextView!
    
    

    @IBAction func loadLogin(_ sender: UIButton) {
        performSegue(withIdentifier: "loginsegue", sender: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        
        UIView.animate(withDuration: 0.7, animations: {
            self.logoImageView.frame.size = CGSize(width: 100, height: 100)
            self.logoImageView.center = CGPoint(x:self.view.frame.size.width/2,y:self.view.frame.size.height/6)
            self.view.backgroundColor = UIColor.cyan
            
        }) {(status) in
            UIView.animate(withDuration: 0.7) {
                self.textView.alpha = 1
                self.getStartBtn.alpha = 1
        }
        
        }
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
