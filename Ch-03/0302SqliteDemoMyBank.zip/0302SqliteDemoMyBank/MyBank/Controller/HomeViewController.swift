//
//  HomeViewController.swift
//  MyBank
//
//  Created by Trainer on 3/23/19.
//  Copyright © 2019 Trainer. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    
    @IBOutlet weak var amountLabel:UILabel!
    
    
    @IBAction func save(_sender: UIButton) {
        performSegue(withIdentifier: "savesegue", sender: nil)
    }
    
    @IBAction func withdraw(_ sender: UIButton) {
        performSegue(withIdentifier: "withdrawsegue", sender: nil)
    }
    
    
    @IBAction func Transfer(_ sender: UIButton) {
        performSegue(withIdentifier: "transfersegue", sender: nil)
    }
    
    
    @IBAction func history(_ sender: UIButton) {
        performSegue(withIdentifier: "historysegue", sender: nil)
    }
    
    
    @IBAction func logout(_ sender: UIBarButtonItem) {
        Bank.currentAccount = nil 
        self.navigationController?.dismiss(animated: true, completion: nil)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }

    override func viewWillAppear(_ animated: Bool){
    super.viewWillAppear(animated)
    if let account = Bank.currentAccount {
        amountLabel.text = "Total Amount:\(account.amount)"
        
        
    }
    // Do any additional setup after loading the view.
}

override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
    
}


/*
 // MARK: - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
 // Get the new view controller using segue.destinationViewController.
 // Pass the selected object to the new view controller.
 }
 */

}
