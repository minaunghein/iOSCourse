//
//  TransferViewController.swift
//  MyBank
//
//  Created by Trainer on 3/23/19.
//  Copyright © 2019 Trainer. All rights reserved.
//

import UIKit

class TransferViewController: UIViewController {
    
    @IBOutlet weak var idTextTextField: UITextField!
    @IBOutlet weak var transferAmountTextField: UITextField!
    @IBAction func transfer(_ sender:UIButton){
        
        guard let amountString = transferAmountTextField.text, amountString != "" else {
            print("Invalid amount")
            return
        }
        
        guard let accountToTransfer = idTextTextField.text , accountToTransfer != "", let accountid = Int(accountToTransfer) else{
            print("Invalid account")
            return
        }
        
        let amount = Double(amountString) ?? 0.0
        
        guard let currentAmount = Bank.currentAccount?.amount, currentAmount - amount > 1000 else {
            print("over transfer")
            return
            
        }
        let result = Bank.currentAccount?.transfer(amount , accountid)
        transferAmountTextField.text = ""
        idTextTextField.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
