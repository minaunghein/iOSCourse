//
//  ViewController.swift
//  pictureLive
//
//  Created by Min Aung Hein on 12/2/17.
//  Copyright © 2017 MIC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let imageURLString = "https://dl.dropboxusercontent.com/u/102348619/Apps/Magazine/foodmagazine/jan2017/preview/page1.png"
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    @IBAction func download(_ sender: Any) {
        
        
        if  let imageurl = URL(string: imageURLString) {
            
            //TODO:Step by step for networking
            //1.Config using URLSessionConfigureation.default 
            //2.URLRequest with URL from string
            //3.Create URLSession with configuration
            //4.Create task using URLSession
            //5. Make the task RESUME
            
            //Task -- datatask (data from Memory on the sport  , download from disk progressively , upload )
            
            //URLSession 
            let myconfig = URLSessionConfiguration.default //1
           
            let myurlrequest = URLRequest(url: imageurl) //2
            
            
            let urlsession = URLSession(configuration: myconfig) //3
            
            
            //4
            let task = urlsession.dataTask(with: myurlrequest, completionHandler: { (dataComing, response, error) in
                
                if error == nil {
                
                    if  let rawdata = dataComing  {
                        
                        let mainqueue = OperationQueue.main
                        mainqueue.addOperation {
                            let image = UIImage(data: rawdata)
                            self.imageView.image = image

                        }
                        
                        
                        
                    }
                }
            })
            task.resume()
            
            
        
        }
        
        
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

