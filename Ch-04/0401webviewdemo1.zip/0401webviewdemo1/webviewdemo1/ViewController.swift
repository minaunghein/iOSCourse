//
//  ViewController.swift
//  webviewdemo1
//
//  Created by Min Aung Hein on 5/4/19.
//  Copyright © 2019 Min Aung Hein. All rights reserved.
//

import UIKit
import WebKit
class ViewController: UIViewController , UITextFieldDelegate,WKNavigationDelegate { //1

    @IBOutlet weak var busyInd: UIActivityIndicatorView!
    @IBOutlet weak var textField:UITextField!
    @IBOutlet weak var wkwebView: WKWebView!
    @IBOutlet weak var backBtn: UIBarButtonItem!
    @IBOutlet weak var nextBtn: UIBarButtonItem!
    @IBOutlet weak var refreshBtn: UIBarButtonItem!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        let myURL = URL(string: "http://www.google.com")!
        var request = URLRequest(url:myURL)
        //request.httpMethod = "GET"
        wkwebView.load(request)
        wkwebView.navigationDelegate =  self
        textField.delegate = self //2
        
    }

    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        view.bringSubviewToFront(busyInd)
        refreshBtn.isEnabled = false
        showBusy()
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        backBtn.isEnabled = webView.canGoBack
        nextBtn.isEnabled = webView.canGoForward
        refreshBtn.isEnabled = true
        hideBusy()
    }
    
    
    @IBAction func goback(_ sender: UIBarButtonItem) {
        wkwebView.goBack()
    }
    
    @IBAction func goForward(_ sender: UIBarButtonItem) {
        wkwebView.goForward()
    }
    
    @IBAction func reload(_ sender: UIBarButtonItem) {
        wkwebView.reload()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let address =  textField.text ?? ""
        let myURL = URL(string: address)!
        let request = URLRequest(url:myURL)
        //request.httpMethod = "GET"
        wkwebView.load(request)
        textField.resignFirstResponder()
        return true
    }
    
    func showBusy() {
        busyInd.isHidden = false
        busyInd.startAnimating()
    }
    
    func hideBusy() {
        busyInd.isHidden = true
        busyInd.stopAnimating()
    }

}

